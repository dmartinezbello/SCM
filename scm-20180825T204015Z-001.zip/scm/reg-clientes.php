<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
$colname_evitaDuplicado = "-1";
if (isset($_POST['TxNomDep'])) {
  $colname_evitaDuplicado = $_POST['TxNomDep'];
}
mysql_select_db($database_conex, $conex);
$query_evitaDuplicado = sprintf("SELECT AuCodCli FROM clientes WHERE TxNomDep = %s", GetSQLValueString($colname_evitaDuplicado, "text"));
$evitaDuplicado = mysql_query($query_evitaDuplicado, $conex) or die(mysql_error());
$row_evitaDuplicado = mysql_fetch_assoc($evitaDuplicado);
$totalRows_evitaDuplicado = mysql_num_rows($evitaDuplicado);

$error = 0;
if (array_key_exists ('enviar', $_POST) && $totalRows_evitaDuplicado==0){
			if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
			  $insertSQL = sprintf("INSERT INTO clientes (AuCodCli, TxNomDep) VALUES (%s, %s)",
										  GetSQLValueString($_POST['AuCodCli'], "int"),
										  GetSQLValueString($_POST['TxNomDep'], "text"));
			
			  mysql_select_db($database_conex, $conex);
			  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
			  $_POST = array();
			}
}else{$error = 1;}
mysql_select_db($database_conex, $conex);
$query_clientes = "SELECT * FROM clientes ORDER BY TxNomDep ASC";
$clientes = mysql_query($query_clientes, $conex) or die(mysql_error());
$row_clientes = mysql_fetch_assoc($clientes);
$totalRows_clientes = mysql_num_rows($clientes);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;
        <fieldset>
          <legend><h2>Registrar departamentos - clientes</h2></legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" border="0" align="center" cellpadding="5" cellspacing="1">
              <tr valign="baseline">
                <td colspan="2" align="left" nowrap></td>
              </tr>
              <tr valign="baseline">
                <td colspan="2" align="left" nowrap>
                  <?php if ($_POST && $error ==1) { echo '<p class="obligatorio">No se completo el proceso de registro puesto que lo que intenta agregar ya se encuentra en la base de datos</p>';}?>
                  <span id="sprytextfield1">
                  <label>Nombre de departamento: <span class="textfieldRequiredMsg der">Se necesita un valor</span></label>
                  <input name="TxNomDep" type="text" class="textInput" value="" size="32">
                </span></td>
              </tr>
              <tr valign="baseline">
                <td nowrap align="right">&nbsp;</td>
                <td align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Registar"></td>
              </tr>
            </table>
            <input type="hidden" name="AuCodCli" value="">
            <input type="hidden" name="MM_insert" value="form1">
          </form>
        </fieldset>
        <?php if ($totalRows_clientes > 0) { // Show if recordset not empty ?>
  <fieldset>
    <legend><h2>Detalle de registros</h2></legend>
    <table width="100%" border="0" cellpadding="10" cellspacing="1">
      <tr class="Tcabeza">
        <th align="left">Clientes</th>
        <th width="5%">Editar</th>
        <th width="5%">Eliminar</th>
      </tr>
      <?php do { ?>
        <tr>
          <td class="lineaInfPunta"><?php echo $row_clientes['TxNomDep']; ?></td>
          <td width="5%" align="center" class="lineaInfPunta"><img src="img/editar.png" width="16" height="16" alt="editar"></td>
          <td width="5%" align="center" class="lineaInfPunta"><a href="del-cliente.php?cliente=<?php echo $row_clientes['AuCodCli']; ?>"><img src="img/eliminar.png" width="16" height="16" alt="eliminar"></a></td>
        </tr>
        <?php } while ($row_clientes = mysql_fetch_assoc($clientes)); ?>
    </table>
  </fieldset>
  <?php } // Show if recordset not empty ?>      </td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0">
      Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
      Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
  </script>
</body>
</html>
<?php
mysql_free_result($clientes);

mysql_free_result($evitaDuplicado);
?>
