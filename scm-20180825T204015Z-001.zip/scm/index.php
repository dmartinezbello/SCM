<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}
?>
<?php
// *** Validate request to login to this site.
if (!isset($_SESSION)) {
  session_start();
}

$loginFormAction = $_SERVER['PHP_SELF'];
if (isset($_GET['accesscheck'])) {
  $_SESSION['PrevUrl'] = $_GET['accesscheck'];
}

if (isset($_POST['usuario'])) {
  $loginUsername=$_POST['usuario'];
  $password=$_POST['pass'];
  $MM_fldUserAuthorization = "";
  $MM_redirectLoginSuccess = "bienvenida.php";
  $MM_redirectLoginFailed = "index-error.php";
  $MM_redirecttoReferrer = false;
  mysql_select_db($database_conex, $conex);
  
  $LoginRS__query=sprintf("SELECT TxLogUsu, TxPassUsu FROM usuarios WHERE TxLogUsu=%s AND TxPassUsu=%s",
    GetSQLValueString($loginUsername, "text"), GetSQLValueString($password, "text")); 
   
  $LoginRS = mysql_query($LoginRS__query, $conex) or die(mysql_error());
  $loginFoundUser = mysql_num_rows($LoginRS);
  if ($loginFoundUser) {
     $loginStrGroup = "";
    
	if (PHP_VERSION >= 5.1) {session_regenerate_id(true);} else {session_regenerate_id();}
    //declare two session variables and assign them
    $_SESSION['MM_Username'] = $loginUsername;
    $_SESSION['MM_UserGroup'] = $loginStrGroup;	      

    if (isset($_SESSION['PrevUrl']) && false) {
      $MM_redirectLoginSuccess = $_SESSION['PrevUrl'];	
    }
    header("Location: " . $MM_redirectLoginSuccess );
  }
  else {
    header("Location: ". $MM_redirectLoginFailed );
  }
}
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>.:SCM:.</title>
  <link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td align="left" valign="top"><form name="form1" method="POST" action="<?php echo $loginFormAction; ?>" style="margin:0px;">
          <table width="70%" border="0" align="center" cellpadding="10" cellspacing="0" style=" border:1px solid #F0F0F0; margin-left: 15%; margin-top: 15%;">
            <tr>
              <th colspan="4" align="center" class="colorTextRojo"><p>Bienvenido a SCM</p>
                <p>Sistema de Control de Materiales</p>
                <p>Version 1.0</p></th>
            </tr>
            <tr>
              <th colspan="4" align="center"><p class="colorTextRojo">Inicio de Sesi&oacute;n</p></th>
            </tr>
            <tr>
              <th width="5%" align="right">&nbsp;</th>
              <th width="10%" align="right">Usuario:</th>
              <td width="75%"><input name="usuario" type="text" class="textInput" id="usuario"></td>
              <td width="10%">&nbsp;</td>
            </tr>
            <tr>
              <th width="10%" align="right">&nbsp;</th>
              <th width="10%" align="right">Contrase&ntilde;a:</th>
              <td width="80%"><input name="pass" type="password" class="textInput" id="pass"></td>
              <td width="10%">&nbsp;</td>
            </tr>
            <tr>
              <th align="right">&nbsp;</th>
              <th align="right"><?php echo $_SESSION['MM_Username']; ?>&nbsp;</th>
              <td width="80%" align="right"><input name="Ingresar" type="submit" class="button" id="Ingresar" value="Ingresar"></td>
              <td width="10%" align="right">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="4" align="center"><p style="font-size:10px;">Se recomienda el uso de los navegadores Chrome o Firefox  para el uso de esta aplicaci&oacute;n.</p>
                <p><img src="img/Chrome_and_Firefox.jpg" width="58" height="30"></p></td>
            </tr>
          </table>
        </form></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>