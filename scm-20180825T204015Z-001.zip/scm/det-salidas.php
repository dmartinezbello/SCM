<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_salida = "-1";
if (isset($_GET['salida'])) {
  $colname_salida = $_GET['salida'];
}
mysql_select_db($database_conex, $conex);
$query_salida = sprintf("SELECT AuCodSal, DtFecSal, TxObsSal, clientes.TxNomDep, usuarios.TxNomUsu, usuarios.TxApeUsu FROM salidas, clientes, usuarios WHERE salidas.AuCodSal= %s AND clientes.AuCodCli=salidas.AuCodCli AND usuarios.TxLogUsu=salidas.TxLogUsu ", GetSQLValueString($colname_salida, "int"));
$salida = mysql_query($query_salida, $conex) or die(mysql_error());
$row_salida = mysql_fetch_assoc($salida);
$totalRows_salida = mysql_num_rows($salida);

$colname_detalle = "-1";
if (isset($_GET['salida'])) {
  $colname_detalle = $_GET['salida'];
}
mysql_select_db($database_conex, $conex);
$query_detalle = sprintf("SELECT NuCanSal, materiales.TxNomMat, materiales.TxDesMat FROM salidamateriales, materiales WHERE AuCodSal = %s AND materiales.AuCodMat=salidamateriales.AuCodMat", GetSQLValueString($colname_detalle, "int"));
$detalle = mysql_query($query_detalle, $conex) or die(mysql_error());
$row_detalle = mysql_fetch_assoc($detalle);
$totalRows_detalle = mysql_num_rows($detalle);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="67" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10" class="oculto"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">
        <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
          <tr>
            <td><div class="der icono"><img src="img/impresora.png" width="24" height="24" alt="imprimir" onClick="window.print();"></div></td>
          </tr>
          <tr>
            <td width="100%"><h2>Salida de Materiales</h2>
              <p class="colorTextRojo"><strong>Correlativo: </strong><?php echo $row_salida['AuCodSal']; ?></p>
              <p><strong>Fecha:</strong> <?php echo $row_salida['DtFecSal']; ?></p>
              <p><strong>Cliente: </strong><?php echo $row_salida['TxNomDep']; ?></p>
            <p><strong>Observaciones:</strong> <?php echo $row_salida['TxObsSal']; ?></p></td>
          </tr>
        </table>
        <p>&nbsp;</p>
        <table width="95%" border="0" align="center" cellpadding="10" cellspacing="1">
          <tr class="Tcabeza">
            <th width="40%" align="left">Material</th>
            <th width="55%" align="left">Descripci&oacute;n</th>
            <th width="5%">Cantidad</th>
          </tr>
          <?php do { ?>
            <tr>
              <td width="40%" class="lineaInfPunta"><?php echo $row_detalle['TxNomMat']; ?></td>
              <td width="55%" class="lineaInfPunta"><?php echo $row_detalle['TxDesMat']; ?></td>
              <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_detalle['NuCanSal']; ?></td>
            </tr>
            <?php } while ($row_detalle = mysql_fetch_assoc($detalle)); ?>
        </table></td>
    </tr>
    <tr>
      <td height="50" align="right" valign="top"><strong>Proceso realizado por:</strong> <?php echo $row_salida['TxNomUsu']; ?>, <?php echo $row_salida['TxApeUsu']; ?></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($salida);

mysql_free_result($detalle);
?>
