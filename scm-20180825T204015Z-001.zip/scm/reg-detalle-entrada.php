<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

mysql_select_db($database_conex, $conex);
$query_materiales = "SELECT * FROM materiales ORDER BY TxNomMat ASC";
$materiales = mysql_query($query_materiales, $conex) or die(mysql_error());
$row_materiales = mysql_fetch_assoc($materiales);
$totalRows_materiales = mysql_num_rows($materiales);

$colname_entrada = "-1";
if (isset($_GET['entrada'])) {
  $colname_entrada = $_GET['entrada'];
}
mysql_select_db($database_conex, $conex);
$query_entrada = sprintf("SELECT * FROM entrada, proveedores WHERE AuCodEnt = %s AND proveedores.AuCodPro=entrada.AuCodProE", GetSQLValueString($colname_entrada, "int"));
$entrada = mysql_query($query_entrada, $conex) or die(mysql_error());
$row_entrada = mysql_fetch_assoc($entrada);
$totalRows_entrada = mysql_num_rows($entrada);

mysql_select_db($database_conex, $conex);
$query_Agregados = "SELECT *  FROM   entradamateriales ,  materiales, entrada WHERE  entradamateriales.AuCodEnt =".$_GET['entrada']." and entradamateriales.AuCodMat=materiales.AuCodMat AND entrada.AuCodEnt=".$_GET['entrada']."";
$Agregados = mysql_query($query_Agregados, $conex) or die(mysql_error());
$row_Agregados = mysql_fetch_assoc($Agregados);
$totalRows_Agregados = mysql_num_rows($Agregados);

$colname_viejaCantidad = "-1";
if (isset($_POST['AuCodMat'])) {
  $colname_viejaCantidad = $_POST['AuCodMat'];
}
mysql_select_db($database_conex, $conex);
$query_viejaCantidad = sprintf("SELECT NuCanMat FROM materiales WHERE AuCodMat = %s", GetSQLValueString($colname_viejaCantidad, "int"));
$viejaCantidad = mysql_query($query_viejaCantidad, $conex) or die(mysql_error());
$row_viejaCantidad = mysql_fetch_assoc($viejaCantidad);
$totalRows_viejaCantidad = mysql_num_rows($viejaCantidad);


$nuevaCantidad = $row_viejaCantidad['NuCanMat']+$_POST['NuCanEntM'];
if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO entradamateriales (AuCodEntM, AuCodEnt, AuCodMat, NuCanEntM) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodEntM'], "int"),
                       GetSQLValueString($_POST['AuCodEnt'], "int"),
                       GetSQLValueString($_POST['AuCodMat'], "int"),
                       GetSQLValueString($_POST['NuCanEntM'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
  $sSQL="UPDATE scm.materiales SET NuCanMat = ".$nuevaCantidad." WHERE materiales.AuCodMat = ".$_POST['AuCodMat'].""; 
  $Result2 = mysql_query($sSQL, $conex) or die(mysql_error()); 
	
  $_POST = array();
  
  header ('Location: reg-detalle-entrada.php?entrada='.$_GET["entrada"]);
}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">
        <fieldset>
          <legend><h2> Entrada de Materiales</h2></legend>
          <p><strong>Fecha:</strong> <?php echo $row_entrada['DtFecEnt']; ?></p>
          <p><strong>Documento del proveedor:</strong> <?php echo $row_entrada['TxRefEnt']; ?></p>
          <p><strong>Proveedor: </strong><?php echo $row_entrada['TxNomPro']; ?>, <?php echo $row_entrada['TxTelPro']; ?></p>
          <p><strong>Observaciones:</strong> <?php echo $row_entrada['TxObsEnt']; ?></p>
          
        </fieldset>
        <fieldset>
          <legend>
          <h2>Agregar productos</h2>
          </legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" align="center">
              <tr valign="baseline">
                <td width="80%" align="right" nowrap><label>Material:</label>
                  <select name="AuCodMat" class="textInput" style="height:30px;">
                    <?php
do {  
?>
                    <option value="<?php echo $row_materiales['AuCodMat']?>"><?php echo $row_materiales['TxNomMat'].' - '.$row_materiales['TxDesMat']?></option>
                    <?php
} while ($row_materiales = mysql_fetch_assoc($materiales));
  $rows = mysql_num_rows($materiales);
  if($rows > 0) {
      mysql_data_seek($materiales, 0);
	  $row_materiales = mysql_fetch_assoc($materiales);
  }
?>
                </select></td>
                <td width="20%"><span id="sprytextfield1"><label>Cantidad:<span class="textfieldRequiredMsg der">Se necesita un valor</span><span class="textfieldInvalidFormatMsg der">Formato no v�lido.</span></label>
                  
                  <input name="NuCanEntM" type="text" class="textInput" value="" size="32">
                </span></td>
              </tr>
              <tr valign="baseline">
                <td width="80%" align="right" nowrap>&nbsp;</td>
                <td width="20%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Agregar"></td>
              </tr>
            </table>
            <input type="hidden" name="AuCodEnt" value="<?php echo $_GET['entrada']; ?>">
            <input type="hidden" name="MM_insert" value="form1">
          </form>
      </fieldset>
        <fieldset>
          <legend><h2>Materiales agregados</h2></legend>
          <p>&nbsp;</p>
          <table width="100%" border="0" cellpadding="10" cellspacing="1">
            <tr class="Tcabeza">
              <th width="30%" align="left">Material</th>
              <th width="60%" align="left">Descripci&oacute;n</th>
              <th width="5%">Cantidad</th>
              <th width="5%">Eliminar</th>
            </tr>
            <?php do { ?>
              <tr>
                <td width="30%" class="lineaInfPunta"><?php echo $row_Agregados['TxNomMat']; ?></td>
                <td width="60%" class="lineaInfPunta"><?php echo $row_Agregados['TxDesMat']; ?></td>
                <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_Agregados['NuCanEntM']; ?></td>
                <td width="5%" align="center" class="lineaInfPunta"><a href="del-entrada-material.php?material=<?php echo $row_Agregados['AuCodEntM']; ?>&entrada=<?php echo $row_Agregados['AuCodEnt']; ?>&cantidad=<?php echo $row_Agregados['NuCanEntM']; ?>&codigo=<?php echo $row_Agregados['AuCodMat']; ?>"><img src="img/eliminar.png" width="16" height="16" alt="eliminar"></a></td>
              </tr>
              <?php } while ($row_Agregados = mysql_fetch_assoc($Agregados)); ?>
          </table>

      </fieldset></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "integer", {useCharacterMasking:true});
  </script>
</body>
</html>
<?php
mysql_free_result($materiales);

mysql_free_result($entrada);

mysql_free_result($Agregados);

mysql_free_result($viejaCantidad);
?>
