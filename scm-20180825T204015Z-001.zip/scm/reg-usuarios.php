<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_evitaDuplicado = "-1";
if (isset($_POST['TxLogUsu'])) {
  $colname_evitaDuplicado = $_POST['TxLogUsu'];
}
mysql_select_db($database_conex, $conex);
$query_evitaDuplicado = sprintf("SELECT TxLogUsu FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_evitaDuplicado, "text"));
$evitaDuplicado = mysql_query($query_evitaDuplicado, $conex) or die(mysql_error());
$row_evitaDuplicado = mysql_fetch_assoc($evitaDuplicado);
$totalRows_evitaDuplicado = mysql_num_rows($evitaDuplicado);

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
$error=0;
if ($totalRows_evitaDuplicado==0){
	if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
	  $insertSQL = sprintf("INSERT INTO usuarios (TxLogUsu, TxPassUsu, TxNivUsu, TxNomUsu, TxApeUsu) VALUES (%s, %s, %s, %s, %s)",
								  GetSQLValueString($_POST['TxLogUsu'], "text"),
								  GetSQLValueString($_POST['TxPassUsu'], "text"),
								  GetSQLValueString($_POST['TxNivUsu'], "text"),
								  GetSQLValueString($_POST['TxNomUsu'], "text"),
								  GetSQLValueString($_POST['TxApeUsu'], "text"));
	
	  mysql_select_db($database_conex, $conex);
	  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
	  echo "<script language='JavaScript'> alert('El registro se realizo con exito');</script>";
	}
}else{$error=1;}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;
        <fieldset>
          <legend><h2>Registrar usuarios</h2></legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
            <?php if ($_POST && $error ==1) { echo '<p class="obligatorio">No se completo el proceso de registro, ya el nombre de usuario existe</p>';}?>
              <tr valign="baseline">
                <td width="50%" nowrap><label>Nombre de Usuario:</label>
                  <span id="sprytextfield1">
                  <label>
                    <input name="TxLogUsu" type="text" class="textInput" id="TxLogUsu" size="32">
                  </label>
                <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
                <td width="50%"><label>Contrase&ntilde;a:</label>
                  <span id="sprytextfield2">
                  <input name="TxPassUsu" type="password" class="textInput" value="" size="32">
                <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap>&nbsp;</td>
                <td width="50%"><label>Nivel de Acceso:</label>
                  <select name="TxNivUsu" class="textInput">
                    <option value="1" <?php if (!(strcmp(1, ""))) {echo "SELECTED";} ?>>Analista</option>
                    <option value="2" <?php if (!(strcmp(2, ""))) {echo "SELECTED";} ?>>Administrador</option>
                </select></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap>&nbsp;</td>
                <td width="50%">&nbsp;</td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><label class="der">Nombre(s):</label></td>
                <td width="50%"><span id="sprytextfield3">
                  <input name="TxNomUsu" type="text" class="textInput" value="" size="32">
                <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><label class="der">Apellido(s):</label></td>
                <td width="50%"><span id="sprytextfield4">
                  <label>
                    <input name="TxApeUsu" type="text" class="textInput" value="" size="32">
                  </label>
                <span class="textfieldRequiredMsg">Se necesita un valor.</span></span></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap>&nbsp;</td>
                <td width="50%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Registrar"></td>
              </tr>
            </table>
            <input type="hidden" name="MM_insert" value="form1">
          </form>
          <p>&nbsp;</p>
        </fieldset></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3");
var sprytextfield4 = new Spry.Widget.ValidationTextField("sprytextfield4");
var sprytextfield = new Spry.Widget.ValidationTextField("sprytextfield");
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
  </script>
</body>
</html>
<?php
mysql_free_result($evitaDuplicado);
?>
