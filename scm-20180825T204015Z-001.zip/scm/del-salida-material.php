<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_cantidadVieja = "-1";
if (isset($_GET['codigo'])) {
  $colname_cantidadVieja = $_GET['codigo'];
}
mysql_select_db($database_conex, $conex);
$query_cantidadVieja = sprintf("SELECT NuCanMat FROM materiales WHERE AuCodMat = %s", GetSQLValueString($colname_cantidadVieja, "int"));
$cantidadVieja = mysql_query($query_cantidadVieja, $conex) or die(mysql_error());
$row_cantidadVieja = mysql_fetch_assoc($cantidadVieja);
$totalRows_cantidadVieja = mysql_num_rows($cantidadVieja);
$cantidad=$row_cantidadVieja['NuCanMat']+$_GET['cantidad'];
if ((isset($_GET['material'])) && ($_GET['material'] != "")) {
  $deleteSQL = sprintf("DELETE FROM salidamateriales WHERE AuCodSalM=%s",
                       GetSQLValueString($_GET['material'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($deleteSQL, $conex) or die(mysql_error());
  
  $sSQL="UPDATE scm.materiales SET NuCanMat = ".$cantidad." WHERE materiales.AuCodMat = ".$_GET['codigo'].""; 
  $Result2 = mysql_query($sSQL, $conex) or die(mysql_error());
  
  header ('Location: reg-detalle-salida.php?salida='.$_GET["salida"]);
}

mysql_free_result($cantidadVieja);
?>
