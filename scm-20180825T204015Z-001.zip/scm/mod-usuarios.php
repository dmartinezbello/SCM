<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
//evitar abuso
$colname_evitarAbuso = "-1";
if (isset($_POST['TxLogUsu'])) {
  $colname_evitarAbuso = $_POST['TxLogUsu'];
}
mysql_select_db($database_conex, $conex);
$query_evitarAbuso = sprintf("SELECT TxLogUsu, TxPassUsu FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_evitarAbuso, "text"));
$evitarAbuso = mysql_query($query_evitarAbuso, $conex) or die(mysql_error());
$row_evitarAbuso = mysql_fetch_assoc($evitarAbuso);
$totalRows_evitarAbuso = mysql_num_rows($evitarAbuso);
$error=0;
if ($row_evitarAbuso['TxLogUsu']== $_POST['TxLogUsu'] && $row_evitarAbuso['TxPassUsu']==$_POST['viejoPass']){
	if ((isset($_POST["MM_update"])) && ($_POST["MM_update"] == "form3")) {
	  $updateSQL = sprintf("UPDATE usuarios SET TxPassUsu=%s WHERE TxLogUsu=%s",
								  GetSQLValueString($_POST['TxPassUsu'], "text"),
								  GetSQLValueString($_POST['TxLogUsu'], "text"));
	
	  mysql_select_db($database_conex, $conex);
	  $Result1 = mysql_query($updateSQL, $conex) or die(mysql_error());
	  echo "<script language='JavaScript'> alert('El registro de actualizacion de contrasena se realizo con exito');</script>";
	
	}
}else{$error=1;}

if (array_key_exists('buscar',$_POST)){

}
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>.:SCM:.</title>
  <link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;
        <fieldset>
          <legend>
          <h2>Editar usuarios</h2>
          </legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
              <tr valign="baseline"> </tr>
              <tr valign="baseline"> </tr>
              <tr valign="baseline"> </tr>
            </table>
          </form>
          <form method="post" name="form3" action="<?php echo $editFormAction; ?>">
            <table width="70%" align="center" cellpadding="10" cellspacing="0">
              <?php if (array_key_exists('enviar',$_POST) && $error ==1) { echo '<p class="obligatorio">No se completo el proceso de registro, porque no concuerdan el nombre de usuario y la contrasena</p>';}?>
              <tr valign="baseline">
                <td align="right" valign="top" nowrap><label class="der">Nombre de Usuario:</label></td>
                <td align="left" valign="top"><input name="TxLogUsu" type="text" class="textInput" value=""></td>
              </tr>
              <tr valign="baseline">
                <td nowrap align="right"><label class="der">Contrasena actual:</label></td>
                <td><input name="viejoPass" type="password" class="textInput" id="viejoPass" value="" size="32"></td>
              </tr>
              <tr valign="baseline">
                <td nowrap align="right"><label class="der">Contrasena nueva:</label>
                  &nbsp;</td>
                <td><input name="TxPassUsu" type="password" class="textInput" id="TxPassUsu"></td>
              </tr>
              <tr valign="baseline">
                <td nowrap align="right">&nbsp;</td>
                <td align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Confirmar"></td>
              </tr>
            </table>
            <input type="hidden" name="MM_update" value="form3">
          </form>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
      </fieldset></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($evitarAbuso);
?>
