<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

mysql_select_db($database_conex, $conex);
$query_correlativo = "SELECT * FROM entrada";
$correlativo = mysql_query($query_correlativo, $conex) or die(mysql_error());
$row_correlativo = mysql_fetch_assoc($correlativo);
$totalRows_correlativo = mysql_num_rows($correlativo);

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO entrada (AuCodEnt, DtFecEnt, TxRefEnt, AuCodProE, TxObsEnt, TxLogUsu) VALUES (%s, %s, %s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodEnt'], "int"),
                       GetSQLValueString($_POST['DtFecEnt'], "date"),
                       GetSQLValueString($_POST['TxRefEnt'], "text"),
                       GetSQLValueString($_POST['AuCodProE'], "int"),
                       GetSQLValueString($_POST['TxObsEnt'], "text"),
                       GetSQLValueString($_POST['TxLogUsu'], "text"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());

  $insertGoTo = "reg-detalle-entrada.php?entrada=".$_POST['AuCodEnt']."";
  if (isset($_SERVER['QUERY_STRING'])) {
    $insertGoTo .= (strpos($insertGoTo, '?')) ? "&" : "?";
    $insertGoTo .= $_SERVER['QUERY_STRING'];
  }
  header(sprintf("Location: %s", $insertGoTo));
}

mysql_select_db($database_conex, $conex);
$query_proveedores = "SELECT * FROM proveedores ORDER BY TxNomPro ASC";
$proveedores = mysql_query($query_proveedores, $conex) or die(mysql_error());
$row_proveedores = mysql_fetch_assoc($proveedores);
$totalRows_proveedores = mysql_num_rows($proveedores);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>.:SCM:.</title>
  <script type="text/javascript" src="recursos/popcalendar.js"></script>
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
  <link href="css/scm.css" rel="stylesheet" type="text/css">
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;
        <fieldset>
          <legend>
          <h2>Registrar Entrada de Materiales</h2>
          </legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
              <tr valign="baseline">
                <td align="right" nowrap><span id="sprytextfield1">
                  <label>Fecha:<span class="textfieldRequiredMsg der">Se necesita un valor</span></label>
                  <input name="DtFecEnt" type="text" class="textInput" id="DtFecEnt" size="32" onClick="popCalendar.show(this, 'DtFecEnt')">
                  </span></td>
                <td width="50%"><span id="sprytextfield2">
                  <label>Documento de entrada:<span class="textfieldRequiredMsg der">Se necesita un valor</span></label>
                  <input name="TxRefEnt" type="text" class="textInput" value="" size="32">
                  </span></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><label for="AuCodProE">Proveedor</label>
                  <select name="AuCodProE" class="textInput" id="AuCodProE">
                    <?php
do {  
?>
                    <option value="<?php echo $row_proveedores['AuCodPro']?>"><?php echo $row_proveedores['TxNomPro']?></option>
                    <?php
} while ($row_proveedores = mysql_fetch_assoc($proveedores));
  $rows = mysql_num_rows($proveedores);
  if($rows > 0) {
      mysql_data_seek($proveedores, 0);
	  $row_proveedores = mysql_fetch_assoc($proveedores);
  }
?>
                  </select></td>
                <td width="50%"><input type="hidden" name="AuCodEnt" id="AuCodEnt" value="<?php echo $totalRows_correlativo+1; ?>"></td>
              </tr>
              <tr valign="baseline">
                <td colspan="2" align="right" valign="top" nowrap><label>Observaciones:</label>
                  <textarea name="TxObsEnt" cols="50" rows="5"></textarea></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><input type="hidden" name="TxLogUsu" value="admin" size="32"></td>
                <td width="50%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Registrar"></td>
              </tr>
            </table>
            <input type="hidden" name="MM_insert" value="form1">
          </form>
        </fieldset></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
  </script>
</body>
</html>
<?php
mysql_free_result($proveedores);

mysql_free_result($correlativo);
?>
