<?php @session_start();?>
<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_entrdas = "SELECT * FROM entrada, proveedores WHERE proveedores.AuCodPro=entrada.AuCodProE ORDER BY AuCodEnt ASC";
$entrdas = mysql_query($query_entrdas, $conex) or die(mysql_error());
$row_entrdas = mysql_fetch_assoc($entrdas);
$totalRows_entrdas = mysql_num_rows($entrdas);

$colname_obtenerNivel = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_obtenerNivel = $_SESSION['MM_Username'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerNivel = sprintf("SELECT TxNivUsu FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_obtenerNivel, "text"));
$obtenerNivel = mysql_query($query_obtenerNivel, $conex) or die(mysql_error());
$row_obtenerNivel = mysql_fetch_assoc($obtenerNivel);
$totalRows_obtenerNivel = mysql_num_rows($obtenerNivel);
$query_entrdas = "SELECT entrada.AuCodEnt, entrada.DtFecEnt, entrada.TxObsEnt, proveedores.TxNomPro FROM entrada, proveedores WHERE proveedores.AuCodPro=entrada.AuCodProE ORDER BY AuCodEnt ASC";
$entrdas = mysql_query($query_entrdas, $conex) or die(mysql_error());
$row_entrdas = mysql_fetch_assoc($entrdas);
$totalRows_entrdas = mysql_num_rows($entrdas);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10" class="oculto"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><fieldset>
        <legend>
        <h2>Entradas de Materiales</h2>
        </legend><br>
        <table width="100%" border="0" cellpadding="10" cellspacing="1">
          <tr>
            <th colspan="5" align="right">
				<div class="izq">
				  <div class="der icono"><img src="img/impresora.png" width="24" height="24" alt="imprimir" onClick="window.print();"></div>
				</div>
<?php
          $dias = array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","S&aacute;bado");
			 $meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
			 echo $dias[date('w')]." ".date('d')." de ".$meses[date('n')-1]. " del ".date('Y') ;
			 ?>&nbsp;</th>
            </tr>
          <tr class="Tcabeza">
            <th width="5%">Correlativo</th>
            <th width="15%">Fecha</th>
            <th width="25%" align="left">Proveedor</th>
            <th width="45%" align="left">Observaciones</th>
            <?php if ($row_obtenerNivel['TxNivUsu']==2) {?><th width="5%" align="center" class="icono">Eliminar</th><?php }?>
            </tr>
          <?php do { ?>
            <tr>
              <td width="5%" align="center" class="lineaInfPunta"><a href="det-entrada.php?entrada=<?php echo $row_entrdas['AuCodEnt']; ?>"><?php echo $row_entrdas['AuCodEnt']; ?></a></td>
              <td width="15%" align="center" class="lineaInfPunta"><?php echo $row_entrdas['DtFecEnt']; ?></td>
              <td width="25%" class="lineaInfPunta"><?php echo $row_entrdas['TxNomPro']; ?></td>
              <td width="45%" class="lineaInfPunta"><?php echo $row_entrdas['TxObsEnt']; ?></td>
              <?php if ($row_obtenerNivel['TxNivUsu']==2) {?><td width="5%" align="center" class="lineaInfPunta icono"><a href="del-entrada.php?entrada=<?php echo $row_entrdas['AuCodEnt']; ?>"><img src="img/eliminar.png" width="16" height="16" alt="eliminar"></a></td><?php }?>
              </tr>
            <?php } while ($row_entrdas = mysql_fetch_assoc($entrdas)); ?>
        </table>

      </fieldset></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($entrdas);

mysql_free_result($obtenerNivel);
?>
