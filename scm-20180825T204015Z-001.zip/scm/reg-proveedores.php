<?php require_once('Connections/conex.php'); ?>
<?php
if (!isset($_SESSION)) {
  session_start();
}
$MM_authorizedUsers = "";
$MM_donotCheckaccess = "true";

// *** Restrict Access To Page: Grant or deny access to this page
function isAuthorized($strUsers, $strGroups, $UserName, $UserGroup) { 
  // For security, start by assuming the visitor is NOT authorized. 
  $isValid = False; 

  // When a visitor has logged into this site, the Session variable MM_Username set equal to their username. 
  // Therefore, we know that a user is NOT logged in if that Session variable is blank. 
  if (!empty($UserName)) { 
    // Besides being logged in, you may restrict access to only certain users based on an ID established when they login. 
    // Parse the strings into arrays. 
    $arrUsers = Explode(",", $strUsers); 
    $arrGroups = Explode(",", $strGroups); 
    if (in_array($UserName, $arrUsers)) { 
      $isValid = true; 
    } 
    // Or, you may restrict access to only certain users based on their username. 
    if (in_array($UserGroup, $arrGroups)) { 
      $isValid = true; 
    } 
    if (($strUsers == "") && true) { 
      $isValid = true; 
    } 
  } 
  return $isValid; 
}

$MM_restrictGoTo = "index.php";
if (!((isset($_SESSION['MM_Username'])) && (isAuthorized("",$MM_authorizedUsers, $_SESSION['MM_Username'], $_SESSION['MM_UserGroup'])))) {   
  $MM_qsChar = "?";
  $MM_referrer = $_SERVER['PHP_SELF'];
  if (strpos($MM_restrictGoTo, "?")) $MM_qsChar = "&";
  if (isset($_SERVER['QUERY_STRING']) && strlen($_SERVER['QUERY_STRING']) > 0) 
  $MM_referrer .= "?" . $_SERVER['QUERY_STRING'];
  $MM_restrictGoTo = $MM_restrictGoTo. $MM_qsChar . "accesscheck=" . urlencode($MM_referrer);
  header("Location: ". $MM_restrictGoTo); 
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
$colname_evitaDuplicado = "-1";
if (isset($_POST['TxNomPro'])) {
  $colname_evitaDuplicado = $_POST['TxNomPro'];
}
mysql_select_db($database_conex, $conex);
$query_evitaDuplicado = sprintf("SELECT * FROM proveedores WHERE TxNomPro = %s", GetSQLValueString($colname_evitaDuplicado, "text"));
$evitaDuplicado = mysql_query($query_evitaDuplicado, $conex) or die(mysql_error());
$row_evitaDuplicado = mysql_fetch_assoc($evitaDuplicado);
$totalRows_evitaDuplicado = mysql_num_rows($evitaDuplicado);
$error=0;
if($totalRows_evitaDuplicado==0){
				if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
				  $insertSQL = sprintf("INSERT INTO proveedores (AuCodPro, TxNomPro, TxTelPro, TxDirPro) VALUES (%s, %s, %s, %s)",
											  GetSQLValueString($_POST['AuCodPro'], "int"),
											  GetSQLValueString($_POST['TxNomPro'], "text"),
											  GetSQLValueString($_POST['TxTelPro'], "text"),
											  GetSQLValueString($_POST['TxDirPro'], "text"));
				
				  mysql_select_db($database_conex, $conex);
				  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
				  $_POST = array();
				}
}else {$error=1;}
$maxRows_proveedores = 10;
$pageNum_proveedores = 0;
if (isset($_GET['pageNum_proveedores'])) {
  $pageNum_proveedores = $_GET['pageNum_proveedores'];
}
$startRow_proveedores = $pageNum_proveedores * $maxRows_proveedores;

mysql_select_db($database_conex, $conex);
$query_proveedores = "SELECT * FROM proveedores ORDER BY TxNomPro ASC";
$query_limit_proveedores = sprintf("%s LIMIT %d, %d", $query_proveedores, $startRow_proveedores, $maxRows_proveedores);
$proveedores = mysql_query($query_limit_proveedores, $conex) or die(mysql_error());
$row_proveedores = mysql_fetch_assoc($proveedores);

if (isset($_GET['totalRows_proveedores'])) {
  $totalRows_proveedores = $_GET['totalRows_proveedores'];
} else {
  $all_proveedores = mysql_query($query_proveedores);
  $totalRows_proveedores = mysql_num_rows($all_proveedores);
}
$totalPages_proveedores = ceil($totalRows_proveedores/$maxRows_proveedores)-1;
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>.:SCM:.</title>
  <link href="css/scm.css" rel="stylesheet" type="text/css">
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;
        <fieldset>
          <legend>
          <h2>Registrar Proveedores</h2>
          </legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
             <?php if ($_POST && $error ==1) { echo '<p class="obligatorio">No se completo el proceso de registro puesto que lo que intenta agregar ya se encuentra en la base de datos</p>';}?>

              <tr valign="baseline">
                <td width="50%" align="right" nowrap><span id="sprytextfield1"><label>Proveedor: <span class="textfieldRequiredMsg der">Se necesita un valor</span></label>
                  
                  <input name="TxNomPro" type="text" class="textInput" value="" size="32">
                  </span></td>
                <td width="50%"><span id="sprytextfield2"><label>Telefono: <span class="textfieldInvalidFormatMsg der">Formato no v�lido</span><span class="textfieldRequiredMsg der">Se necesita un valor</span></label>
                  
                  <input name="TxTelPro" type="text" class="textInput" value="" size="32">
                  </span></td>
              </tr>
              <tr valign="baseline">
                <td colspan="2" align="right" valign="top" nowrap><label>Direccion:</label>
                  <textarea name="TxDirPro" cols="50" rows="3"></textarea></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><input type="hidden" name="AuCodPro" value="">
                  <input type="hidden" name="MM_insert" value="form1"></td>
                <td width="50%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Registrar"></td>
              </tr>
            </table>
          </form>
        </fieldset>
        <p>&nbsp;</p>
        <?php if ($totalRows_proveedores > 0) { // Show if recordset not empty ?>
          <fieldset>
            <legend>
            <h2>Detalle de proveedores</h2>
            </legend>
            <table width="100%" border="0" cellpadding="10" cellspacing="1">
              <tr class="Tcabeza">
                <th width="20%" align="left">Proveedor</th>
                <th width="20%" align="left">Telefono</th>
                <th width="50%" align="left">Direccion</th>
                <th width="5%">Editar</th>
                <th width="5%">Eliminar</th>
              </tr>
              <?php do { ?>
                <tr>
                  <td width="20%" class="lineaInfPunta"><?php echo $row_proveedores['TxNomPro']; ?></td>
                  <td width="20%" class="lineaInfPunta"><?php echo $row_proveedores['TxTelPro']; ?></td>
                  <td width="50%" class="lineaInfPunta"><?php echo $row_proveedores['TxDirPro']; ?></td>
                  <td width="5%" align="center" class="lineaInfPunta"><img src="img/editar.png" width="16" height="16" alt="editar"></td>
                  <td width="5%" align="center" class="lineaInfPunta"><a href="del-proveedor.php?proveedor=<?php echo $row_proveedores['AuCodPro']; ?>"><img src="img/eliminar.png" width="16" height="16" alt="eliminar"></a></td>
                </tr>
                <?php } while ($row_proveedores = mysql_fetch_assoc($proveedores)); ?>
            </table>
          </fieldset>
          <?php } // Show if recordset not empty ?></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2", "custom", {pattern:"(0000) - 000 00 00", useCharacterMasking:true});
  </script>
</body>
</html>
<?php
mysql_free_result($proveedores);

mysql_free_result($evitaDuplicado);
?>
