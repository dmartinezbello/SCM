<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}
$colname_evitaDuplicado = "-1";
if (isset($_POST['TxNomMat'])) {
  $colname_evitaDuplicado = $_POST['TxNomMat'];
}
mysql_select_db($database_conex, $conex);
$query_evitaDuplicado = sprintf("SELECT * FROM materiales WHERE TxNomMat = %s", GetSQLValueString($colname_evitaDuplicado, "text"));
$evitaDuplicado = mysql_query($query_evitaDuplicado, $conex) or die(mysql_error());
$row_evitaDuplicado = mysql_fetch_assoc($evitaDuplicado);
$totalRows_evitaDuplicado = mysql_num_rows($evitaDuplicado);

$error=0;
if($totalRows_evitaDuplicado==0){
		if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
		  $insertSQL = sprintf("INSERT INTO materiales (AuCodMat, TxNomMat, TxDesMat, NuCanMat) VALUES (%s, %s, %s, %s)",
									  GetSQLValueString($_POST['AuCodMat'], "int"),
									  GetSQLValueString($_POST['TxNomMat'], "text"),
									  GetSQLValueString($_POST['TxDesMat'], "text"),
									  GetSQLValueString($_POST['NuCanMat'], "int"));
		
		  mysql_select_db($database_conex, $conex);
		  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
		  $_POST = array();
		}
}else{$error=1;}

mysql_select_db($database_conex, $conex);
$query_materiales = "SELECT * FROM materiales ORDER BY TxNomMat ASC";
$materiales = mysql_query($query_materiales, $conex) or die(mysql_error());
$row_materiales = mysql_fetch_assoc($materiales);
$totalRows_materiales = mysql_num_rows($materiales);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>.:SCM:.</title>
  <link href="css/scm.css" rel="stylesheet" type="text/css">
  <link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
  <script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">&nbsp;
        <fieldset>
          <legend>
          <h2>Registrar Materiales</h2>
          </legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
             <?php if ($_POST && $error ==1) { echo '<p class="obligatorio">No se completo el proceso de registro puesto que lo que intenta agregar ya se encuentra en la base de datos</p>';}?>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><span id="sprytextfield1">
                  <label>Material: <span class="textfieldRequiredMsg der">Se necesita un valor</span></label>
                  <input name="TxNomMat" type="text" class="textInput" value="" size="32">
                  </span></td>
                <td width="50%"><span id="sprytextfield2">
                  <label>Descripcion: <span class="textfieldRequiredMsg der">Se necesita un valor</span></label>
                  <input name="TxDesMat" type="text" class="textInput" value="" size="32">
                  </span></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap>&nbsp;</td>
                <td width="50%"><span id="sprytextfield3">
                  <label>Cantidad: <span class="textfieldRequiredMsg der">Se necesita un valor.</span><span class="textfieldInvalidFormatMsg der">Formato no v�lido.</span></label>
                  <input name="NuCanMat" type="text" class="textInput" value="" size="32">
                  </span></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap><input type="hidden" name="MM_insert" value="form1"></td>
                <td width="50%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Registrar"></td>
              </tr>
            </table>
          </form>
        </fieldset>
        <?php if ($totalRows_materiales > 0) { // Show if recordset not empty ?>
          <fieldset>
            <legend>
            <h2>Detalle de Materiales</h2>
            </legend>
            <table width="100%" border="0" cellpadding="10" cellspacing="1">
              <tr class="Tcabeza">
                <th width="5%" align="center">Codigo</th>
                <th width="25%" align="left">Material</th>
                <th width="60%" align="left">Descripcion</th>
                <th width="5%" align="center">Cantidad</th>
                <th width="5%" align="center">Eliminar</th>
              </tr>
              <?php do { ?>
                <tr>
                  <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_materiales['AuCodMat']; ?></td>
                  <td width="25%" class="lineaInfPunta"><?php echo $row_materiales['TxNomMat']; ?></td>
                  <td width="60%" class="lineaInfPunta"><?php echo $row_materiales['TxDesMat']; ?></td>
                  <td width="5%" class="lineaInfPunta" align="center"><?php echo $row_materiales['NuCanMat']; ?></td>
                  <td width="5%" class="lineaInfPunta" align="center"><a href="del-material.php?material=<?php echo $row_materiales['AuCodMat']; ?>"><img src="img/eliminar.png" width="16" height="16" alt="eliminar"></a></td>
                </tr>
                <?php } while ($row_materiales = mysql_fetch_assoc($materiales)); ?>
            </table>
          </fieldset>
          <?php } // Show if recordset not empty ?></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1");
var sprytextfield2 = new Spry.Widget.ValidationTextField("sprytextfield2");
var sprytextfield3 = new Spry.Widget.ValidationTextField("sprytextfield3", "integer", {useCharacterMasking:true});
  </script>
</body>
</html>
<?php
mysql_free_result($materiales);

mysql_free_result($evitaDuplicado);
?>
