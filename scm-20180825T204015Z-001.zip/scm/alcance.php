<?php session_start();
if(!isset($_SESSION['MM_Username'])){
header("location:index.php");} ?>
<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_identificarUsuario = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_identificarUsuario = $_SESSION['MM_Username'];
}
mysql_select_db($database_conex, $conex);
$query_identificarUsuario = sprintf("SELECT * FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_identificarUsuario, "text"));
$identificarUsuario = mysql_query($query_identificarUsuario, $conex) or die(mysql_error());
$row_identificarUsuario = mysql_fetch_assoc($identificarUsuario);
$totalRows_identificarUsuario = mysql_num_rows($identificarUsuario);
 
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>.:SCM:.</title>
  <link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">
        <table width="70%" border="0" align="center" cellpadding="10" cellspacing="0" style=" margin-left: 15%; margin-top: 2%;">
            <tr>
              <th align="center" class=" obligatorio"><h1>Normas</h1></th>
            </tr>
            <tr>
              <th width="100%">
<p style="text-align:justify;">. Al ingresar los bienes y materiales al almac�n. Despu�s de efectuado el descargue debe procederse al desembalaje de las cajas, paquetes, etc., tratando de no danar los bienes.</p>
<p style="text-align:justify;">&nbsp;</p>
<p style="text-align:justify;">. El responsable del almac�n solo podr� recibir materiales o bienes que vengan amparados con la respectiva factura del proveedor, la que debe corresponder con la Orden de Compra elaborada por la Unidad de Compras.  </p>
<p style="text-align:justify;">&nbsp;</p>
<p style="text-align:justify;">. Cuando los materiales a recepcionarse sean en cantidades voluminosas y que no se puedan contar en su totalidad en el momento de la recepci�n, el Responsable del almac�n deber� contar en un 100% los material recibidos, si el resultado del conteo tiene inconsistencia, se deber� realizar un conteo del contenido de todos las cajas o bultos. Cualquier diferencia se deber� informar inmediatamente al Responsable, quien deber� tomar las medidas del caso.</p>
             </p></th>
            </tr>
            <tr>
              <th align="center" class="colorTextRojo">&nbsp;</th>
            </tr>
          </table>
      </td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($identificarUsuario);
?>
