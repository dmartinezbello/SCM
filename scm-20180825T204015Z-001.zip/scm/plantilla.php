<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="20"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td>
      <div id="contenedor" style="width:100%; height:100%;">

Contenido que tiene que ocupar todo el espacio del navegador.

</div>
      
      </td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0">
      Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
      Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>