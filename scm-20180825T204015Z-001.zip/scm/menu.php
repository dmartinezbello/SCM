<?php @session_start();?>
<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_obtenerNivel = "-1";
if (isset($_SESSION['MM_Username'])) {
  $colname_obtenerNivel = $_SESSION['MM_Username'];
}
mysql_select_db($database_conex, $conex);
$query_obtenerNivel = sprintf("SELECT TxNivUsu FROM usuarios WHERE TxLogUsu = %s", GetSQLValueString($colname_obtenerNivel, "text"));
$obtenerNivel = mysql_query($query_obtenerNivel, $conex) or die(mysql_error());
$row_obtenerNivel = mysql_fetch_assoc($obtenerNivel);
$totalRows_obtenerNivel = mysql_num_rows($obtenerNivel);
 ?>

  <div id='cssmenu'>
    <ul>
      <li class='has-sub '><a href='#'>Registro</a>
        <ul>
          <li><a href='reg-materiales.php'>Materiales</a></li>
          <li><a href='reg-clientes.php'>Cliente</a></li>
          <li><a href='reg-proveedores.php'>Proveedores</a></li>
        </ul>
      </li>
      <li class='has-sub '><a href='#'>Reportes</a>
        <ul>
          <li><a href='rep-proveedores.php'>Proveedores</a></li>
          <li><a href='rep-entradas.php'>Entradas</a></li>
          <li><a href='rep-salidas.php'>Salidas</a></li>
          <li><a href='rep-materiales.php'>Inventario al Dia</a></li>
          <li><a href='kardex.php'>Kardex</a></li>
        </ul>
      </li>
      <li class='has-sub '><a href='#'>Operaciones</a>
        <ul>
          <li><a href='reg-entradas.php'>Entrada de Materiales</a></li>
          <li><a href='reg-salida.php'>Salida de Materiales</a></li>
          <?php if ($row_obtenerNivel['TxNivUsu']==2) {?><li><a href='reg-usuarios.php'>Registro de Usuario</a></li><?php }?>
          <li><a href='mod-usuarios.php'>Modificar de Usuario</a></li>
        </ul>
      </li>
      <li class='has-sub '><a href='#'>Acerca de</a>
        <ul>
          <li><a href='mision.php'>Mision</a></li>
          <li><a href='vision.php'>Vision</a></li>
          <li><a href='organigrama.php'>Objetivo</a></li>
          <li><a href='alcance.php'>Normas</a></li>
          <li><a href='ayuda.php'>Ayuda</a></li>
          <li><a href='contactos.php'>Contactos</a></li>
        </ul>
      </li>
      <li><a href='cerrar-sesion.php'>Cerrar Sesion</a></li>
    </ul>
  </div>
  <?php
mysql_free_result($obtenerNivel);
?>
