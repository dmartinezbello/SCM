<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_producto = "SELECT * FROM materiales ORDER BY TxNomMat ASC";
$producto = mysql_query($query_producto, $conex) or die(mysql_error());
$row_producto = mysql_fetch_assoc($producto);
$totalRows_producto = mysql_num_rows($producto);

if (array_key_exists('buscar',$_POST) && $_POST['trans']=='salidas'){
mysql_select_db($database_conex, $conex);
$query_salida = "SELECT salidas.AuCodSal, salidas.DtFecSal, salidas.TxObsSal, clientes.TxNomDep FROM salidas, clientes WHERE clientes.AuCodCli=salidas.AuCodCli AND DtFecSal Between '".$_POST['fechaI']."' AND '".$_POST['fechaF']."' ORDER BY DtFecSal ASC";
$salida = mysql_query($query_salida, $conex) or die(mysql_error());
$row_salida = mysql_fetch_assoc($salida);
$totalRows_salida = mysql_num_rows($salida);
 }
 
if (array_key_exists('buscar',$_POST) && $_POST['trans']=='entrada'){
mysql_select_db($database_conex, $conex);
$query_kardex = "SELECT entrada.AuCodEnt, entrada.DtFecEnt, entrada.TxObsEnt, proveedores.TxNomPro FROM entrada, proveedores WHERE proveedores.AuCodPro=entrada.AuCodProE AND DtFecEnt Between '".$_POST['fechaI']."' AND '".$_POST['fechaF']."'";
$kardex = mysql_query($query_kardex, $conex) or die(mysql_error());
$row_kardex = mysql_fetch_assoc($kardex);
$totalRows_kardex = mysql_num_rows($kardex);
}
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>Kardex</title>
<script type="text/javascript" src="recursos/popcalendar.js"></script>
<link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body class="top">
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"  class="oculto"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">
        <fieldset class="icono">
          <legend>
          <h2>Registrar Salida de Materiales</h2>
          </legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
              <tr valign="baseline">
                <td width="50%" align="left" nowrap><label for="trans">Tipo de transacci&oacute;n:</label>
                  <select name="trans" class="textInput" id="trans">
                    <option value="entrada">Entrada</option>
                    <option value="salidas">Salida</option>
                </select></td>
                <td width="50%">&nbsp;</td>
              </tr>
              <tr valign="baseline">
                <td align="left" nowrap><label for="fechaI">Fecha de inicio:</label>
                <input name="fechaI" type="text" class="textInput" id="fechaI" onClick="popCalendar.show(this, 'fechaI')" value="<?php echo date('Y-m-d'); ?>"></td>
                <td align="left"><label for="fechaF">Fecha final:</label>
                <input name="fechaF" type="text" class="textInput" id="fechaF" onClick="popCalendar.show(this, 'fechaF')" value="<?php echo date('Y-m-d'); ?>"></td>
              </tr>
              <tr valign="baseline">
                <td width="50%" align="right" nowrap></td>
                <td width="50%" align="right"><input name="buscar" type="submit" class="button" id="buscar" value="Buscar"></td>
              </tr>
            </table>
          </form>
          <table width="100%" border="0" align="center" cellpadding="10" cellspacing="0">
            <tr valign="baseline"> </tr>
          </table>
        </fieldset>
        <?php if ($totalRows_kardex > 0) { // Show if recordset not empty ?>
        <table width="95%" border="0" align="center" cellpadding="10" cellspacing="1">
          <tr>
            <th colspan="4" align="left"><div class="der icono"><img src="img/impresora.png" width="24" height="24" alt="imprimir" onClick="window.print();"></div></th>
          </tr>
          <tr>
            <th colspan="4" align="left">
            
            Filtro: <?php echo 'Tipo de transaccion: '.$_POST['trans'].', desde: '.$_POST['fechaI'].' hasta: '.$_POST['fechaF'] ?>
            <span class="der">Resultados obtenidos (<?php echo $totalRows_kardex; ?>)</span>
            </th>
          </tr>
          <tr class="Tcabeza">
            <th width="10%">Correlativo</th>
            <th width="25%" align="left">Fecha</th>
            <th width="30%" align="left">Proveedor</th>
            <th width="35%" align="left">Observaciones</th>
          </tr>
          <?php do { ?>
          <tr>
            <td width="10%" align="center" class="lineaInfPunta"><a href="det-entrada.php?entrada=<?php echo $row_kardex['AuCodEnt']; ?>"><?php echo $row_kardex['AuCodEnt']; ?></a></td>
            <td width="25%" class="lineaInfPunta"><?php echo $row_kardex['DtFecEnt']; ?></td>
            <td width="30%" class="lineaInfPunta"><?php echo $row_kardex['TxNomPro']; ?></td>
            <td width="35%" class="lineaInfPunta"><?php echo $row_kardex['TxObsEnt']; ?></td>
          </tr>
          <?php } while ($row_kardex = mysql_fetch_assoc($kardex)); ?>
        </table>
        <?php } // Show if recordset not empty ?>
        <?php if ($totalRows_salida > 0) { // Show if recordset not empty ?>
  <table width="95%" border="0" align="center" cellpadding="10" cellspacing="1">
    <tr>
      <th colspan="5" align="left"><div class="der icono"><img src="img/impresora.png" width="24" height="24" alt="imprimir" onClick="window.print();"></div></th>
    </tr>
    <tr>
      <th colspan="5" align="left">Filtro: <?php echo 'Tipo de transaccion: '.$_POST['trans'].' desde: '.$_POST['fechaI'].' hasta: '.$_POST['fechaF'] ?><span class="der">Resultados obtenidos (<?php echo $totalRows_salida; ?>)</span></th>
    </tr>
    <tr class="Tcabeza">
      <th>Correlativo</th>
      <th align="left">Cliente</th>
      <th align="left">Fecha de salida</th>
      <th align="left">Observaciones</th>
    </tr>
    <?php do { ?>
      <tr>
        <td align="center" class="lineaInfPunta"><a href="det-salidas.php?salida=<?php echo $row_salida['AuCodSal']; ?>"><?php echo $row_salida['AuCodSal']; ?></a></td>
        <td class="lineaInfPunta"><?php echo $row_salida['TxNomDep']; ?></td>
        <td class="lineaInfPunta"><?php echo $row_salida['DtFecSal']; ?></td>
        <td class="lineaInfPunta"><?php echo $row_salida['TxObsSal']; ?></td>
      </tr>
      <?php } while ($row_salida = mysql_fetch_assoc($salida)); ?>
  </table>
  <?php } // Show if recordset not empty ?></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almac&eacute;n del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>
<?php
//mysql_free_result($producto);
//
//mysql_free_result($salida);
//
//mysql_free_result($kardex);
?>
