<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conex, $conex);
$query_proveedores = "SELECT * FROM proveedores ORDER BY TxNomPro ASC";
$proveedores = mysql_query($query_proveedores, $conex) or die(mysql_error());
$row_proveedores = mysql_fetch_assoc($proveedores);
$totalRows_proveedores = mysql_num_rows($proveedores);
?>
<!doctype html>
<html>
<head>
  <meta charset="iso-8859-2">
  <title>.:SCM:.</title>
  <link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0" class="altoFul">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10" class="oculto"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top"><fieldset>
          <legend><h2>Inventario de proveedores</h2></legend><br>
          <table width="100%" border="0" cellpadding="10" cellspacing="1">
            <tr>
              <th colspan="4" align="right">
              <div class="izq">
                <div class="der icono"><img src="img/impresora.png" width="24" height="24" alt="imprimir" onClick="window.print();"></div>
              </div>
              <?php
          $dias = array("Domingo","Lunes","Martes","Miercoles","Jueves","Viernes","S&aacute;bado");
			 $meses = array("Enero","Febrero","Marzo","Abril","Mayo","Junio","Julio","Agosto","Septiembre","Octubre","Noviembre","Diciembre");
			 echo $dias[date('w')]." ".date('d')." de ".$meses[date('n')-1]. " del ".date('Y') ;
			 ?>
              </th>
            </tr>
            <tr class="Tcabeza">
              <th width="10%">C&oacute;digo</th>
              <th width="30%" align="left">Proveedor</th>
              <th width="15%">Tel&eacute;fono</th>
              <th width="55%">Direcci&oacute;n</th>
            </tr>
            <?php do { ?>
              <tr>
                <td width="10%" class="lineaInfPunta"><?php echo $row_proveedores['AuCodPro']; ?></td>
                <td width="30%" class="lineaInfPunta"><?php echo $row_proveedores['TxNomPro']; ?></td>
                <td width="15%" class="lineaInfPunta"><?php echo $row_proveedores['TxTelPro']; ?></td>
                <td width="55%" class="lineaInfPunta"><?php echo $row_proveedores['TxDirPro']; ?></td>
              </tr>
              <?php } while ($row_proveedores = mysql_fetch_assoc($proveedores)); ?>
          </table>
        </fieldset></td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($proveedores);
?>
