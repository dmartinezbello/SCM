<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$editFormAction = $_SERVER['PHP_SELF'];
if (isset($_SERVER['QUERY_STRING'])) {
  $editFormAction .= "?" . htmlentities($_SERVER['QUERY_STRING']);
}

//Obtener el stock del producto

$colname_viejaCantidad = "-1";
if (isset($_POST['AuCodMat'])) {
  $colname_viejaCantidad = $_POST['AuCodMat'];
}

mysql_select_db($database_conex, $conex);
$query_viejaCantidad = sprintf("SELECT NuCanMat FROM materiales WHERE AuCodMat = %s", GetSQLValueString($colname_viejaCantidad, "int"));
$viejaCantidad = mysql_query($query_viejaCantidad, $conex) or die(mysql_error());
$row_viejaCantidad = mysql_fetch_assoc($viejaCantidad);
$totalRows_viejaCantidad = mysql_num_rows($viejaCantidad);
$cantidad = $row_viejaCantidad['NuCanMat'] - $_POST['NuCanSal'];

if ((isset($_POST["MM_insert"])) && ($_POST["MM_insert"] == "form1")) {
  $insertSQL = sprintf("INSERT INTO salidamateriales (AuCodSalM, AuCodSal, AuCodMat, NuCanSal) VALUES (%s, %s, %s, %s)",
                       GetSQLValueString($_POST['AuCodSalM'], "int"),
                       GetSQLValueString($_POST['AuCodSal'], "int"),
                       GetSQLValueString($_POST['AuCodMat'], "int"),
                       GetSQLValueString($_POST['NuCanSal'], "int"));

  mysql_select_db($database_conex, $conex);
  $Result1 = mysql_query($insertSQL, $conex) or die(mysql_error());
  
  $sSQL="UPDATE scm.materiales SET NuCanMat = ".$cantidad." WHERE materiales.AuCodMat = ".$_POST['AuCodMat'].""; 
  $Result2 = mysql_query($sSQL, $conex) or die(mysql_error()); 
  
  header ('Location: reg-detalle-salida.php?salida='.$_GET["salida"]);
}

$colname_salidas = "-1";
if (isset($_GET['salida'])) {
  $colname_salidas = $_GET['salida'];
}
mysql_select_db($database_conex, $conex);
$query_salidas = sprintf("SELECT * FROM salidas, clientes WHERE AuCodSal = %s AND clientes.AuCodCli=salidas.AuCodCli", GetSQLValueString($colname_salidas, "int"));
$salidas = mysql_query($query_salidas, $conex) or die(mysql_error());
$row_salidas = mysql_fetch_assoc($salidas);
$totalRows_salidas = mysql_num_rows($salidas);

mysql_select_db($database_conex, $conex);
$query_materiales = "SELECT * FROM materiales ORDER BY TxNomMat ASC";
$materiales = mysql_query($query_materiales, $conex) or die(mysql_error());
$row_materiales = mysql_fetch_assoc($materiales);
$totalRows_materiales = mysql_num_rows($materiales);

$colname_DetalleAgregados = "-1";
if (isset($_GET['salida'])) {
  $colname_DetalleAgregados = $_GET['salida'];
}
mysql_select_db($database_conex, $conex);
$query_DetalleAgregados = sprintf("SELECT materiales.TxNomMat, materiales.TxDesMat, salidamateriales.NuCanSal, salidamateriales.AuCodSalM, materiales.AuCodMat FROM salidamateriales, materiales WHERE salidamateriales.AuCodSal = %s AND salidamateriales.AuCodMat=materiales.AuCodMat", GetSQLValueString($colname_DetalleAgregados, "int"));
$DetalleAgregados = mysql_query($query_DetalleAgregados, $conex) or die(mysql_error());
$row_DetalleAgregados = mysql_fetch_assoc($DetalleAgregados);
$totalRows_DetalleAgregados = mysql_num_rows($DetalleAgregados);

?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
<link href="SpryAssets/SpryValidationTextField.css" rel="stylesheet" type="text/css">
<script src="SpryAssets/SpryValidationTextField.js" type="text/javascript"></script>
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="79" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">
        <fieldset>
          <legend>
          <h2> Salida de Materiales</h2>
          </legend>
          <p><strong>N&uacute;mero de salida:</strong> <span class="obligatorio"><?php echo $row_salidas['AuCodSal']; ?></span></p>
          <p><strong>Fecha:</strong> <?php echo $row_salidas['DtFecSal']; ?></p>
          <p><strong>Cliente: </strong><?php echo $row_salidas['TxNomDep']; ?></p>
          <p><strong>Observaciones:</strong> <?php echo $row_salidas['TxObsSal']; ?></p>
          
        </fieldset>
        <fieldset>
          <legend>
          <h2>Agregar productos</h2>
          </legend>
          <form method="post" name="form1" action="<?php echo $editFormAction; ?>">
            <table width="100%" align="center" cellpadding="10" cellspacing="0">
              <tr valign="baseline">
                <td width="80%" align="right" nowrap><label>Material:</label>
                  <select name="AuCodMat" class="textInput" style=" height:30px;">
                    <?php
do {  
?>
                    <option value="<?php echo $row_materiales['AuCodMat']?>"><?php echo $row_materiales['TxNomMat'].' - '.$row_materiales['TxDesMat'].' dispobible: '.$row_materiales['NuCanMat']?></option>
                    <?php
} while ($row_materiales = mysql_fetch_assoc($materiales));
  $rows = mysql_num_rows($materiales);
  if($rows > 0) {
      mysql_data_seek($materiales, 0);
	  $row_materiales = mysql_fetch_assoc($materiales);
  }
?>
                  </select></td>
                <td width="20%"><label>Cantidad:</label>
                  <span id="sprytextfield1">
                  <input name="NuCanSal" type="text" class="textInput" value="" size="32">
                <span class="textfieldRequiredMsg">Se necesita un valor.</span><span class="textfieldInvalidFormatMsg">Formato no v�lido.</span></span></td>
              </tr>
              <tr valign="baseline">
                <td width="80%" align="right" nowrap>&nbsp;</td>
                <td width="20%" align="right"><input name="enviar" type="submit" class="button" id="enviar" value="Agregar"></td>
              </tr>
            </table>
            <input type="hidden" name="MM_insert" value="form1">
            <input type="hidden" name="AuCodSalM" value="" size="32">
            <input type="hidden" name="AuCodSal" value="<?php echo $_GET['salida'] ?>" size="32">
          </form>
          <p>&nbsp;</p>
        </fieldset>
        <?php if ($totalRows_DetalleAgregados > 0) { // Show if recordset not empty ?>
  <fieldset>
    <legend><h2>Materiales agregados</h2></legend>
    <table width="100%" border="0" cellpadding="10" cellspacing="1">
      <tr class="Tcabeza">
        <th width="30%" align="left">Material</th>
        <th width="60%" align="left">Descripci&oacute;n</th>
        <th width="5%">Cantidad</th>
        <th width="5%">Eliminar</th>
      </tr>
      <?php do { ?>
        <tr>
          <td width="30%" class="lineaInfPunta"><?php echo $row_DetalleAgregados['TxNomMat']; ?></td>
          <td width="60%" class="lineaInfPunta"><?php echo $row_DetalleAgregados['TxDesMat']; ?></td>
          <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_DetalleAgregados['NuCanSal']; ?></td>
          <td width="5%" align="center" class="lineaInfPunta"><a href="del-salida-material.php?material=<?php echo $row_DetalleAgregados['AuCodSalM']; ?>&salida=<?php echo $row_salidas['AuCodSal']; ?>&cantidad=<?php echo $row_DetalleAgregados['NuCanSal']; ?>&codigo=<?php echo $row_DetalleAgregados['AuCodMat']; ?>"><img src="img/eliminar.png" width="16" height="16" alt="eliminar"></a></td>
        </tr>
        <?php } while ($row_DetalleAgregados = mysql_fetch_assoc($DetalleAgregados)); ?>
    </table>
  </fieldset>
  <?php } // Show if recordset not empty ?>      </td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
  <script type="text/javascript">
var sprytextfield1 = new Spry.Widget.ValidationTextField("sprytextfield1", "integer", {useCharacterMasking:true});
  </script>
</body>
</html>
<?php
mysql_free_result($salidas);

mysql_free_result($materiales);

mysql_free_result($DetalleAgregados);

mysql_free_result($viejaCantidad);
?>
