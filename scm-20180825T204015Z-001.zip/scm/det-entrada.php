<?php require_once('Connections/conex.php'); ?>
<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

$colname_entrada = "-1";
if (isset($_GET['entrada'])) {
  $colname_entrada = $_GET['entrada'];
}
mysql_select_db($database_conex, $conex);
$query_entrada = sprintf("SELECT * FROM entrada, proveedores WHERE AuCodEnt = %s AND proveedores.AuCodPro=entrada.AuCodProE", GetSQLValueString($colname_entrada, "int"));
$entrada = mysql_query($query_entrada, $conex) or die(mysql_error());
$row_entrada = mysql_fetch_assoc($entrada);
$totalRows_entrada = mysql_num_rows($entrada);

mysql_select_db($database_conex, $conex);
$query_Agregados = "SELECT *  FROM   entradamateriales ,  materiales, entrada WHERE  entradamateriales.AuCodEnt =".$_GET['entrada']." and entradamateriales.AuCodMat=materiales.AuCodMat AND entrada.AuCodEnt=".$_GET['entrada']."";
$Agregados = mysql_query($query_Agregados, $conex) or die(mysql_error());
$row_Agregados = mysql_fetch_assoc($Agregados);
$totalRows_Agregados = mysql_num_rows($Agregados);
?>
<!doctype html>
<html>
<head>
<meta charset="iso-8859-2">
<title>.:SCM:.</title>
<link href="css/scm.css" rel="stylesheet" type="text/css">
</head>

<body>
  <table id="cuerpo" width="800" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td height="67"><img src="img/cabecera.png" width="800" height="67" alt="Cabecera"></td>
    </tr>
    <tr>
      <td height="10" class="oculto"><?php include('menu.php'); ?></td>
    </tr>
    <tr>
      <td align="left" valign="top">
        <table width="95%" border="0" align="center" cellpadding="10" cellspacing="0">
          <tr>
            <td><div class="der icono"><img src="img/impresora.png" width="24" height="24" alt="imprimir" onClick="window.print();"></div></td>
          </tr>
          <tr>
            <td width="100%"><h2>Entrada de Materiales</h2>
              <p class="colorTextRojo"><strong>Correlativo: </strong><?php echo $row_entrada['AuCodEnt']; ?></p>
              <p><strong>Fecha:</strong> <?php echo $row_entrada['DtFecEnt']; ?></p>
              <p><strong>Documento del proveedor:</strong> <?php echo $row_entrada['TxRefEnt']; ?></p>
              <p><strong>Proveedor: </strong><?php echo $row_entrada['TxNomPro']; ?>, <?php echo $row_entrada['TxTelPro']; ?></p>
            <p><strong>Observaciones:</strong> <?php echo $row_entrada['TxObsEnt']; ?></p></td>
          </tr>
        </table>
        <table width="95%" border="0" align="center" cellpadding="10" cellspacing="1">
          <tr>
              <th colspan="3" align="left"><h2>Materiales</h2></th>
            </tr>
            <tr class="Tcabeza">
              <th width="30%" align="left">Material</th>
              <th width="65%" align="left">Descripci&oacute;n</th>
              <th width="5%">Cantidad</th>
            </tr>
            <?php do { ?>
            <tr>
              <td width="30%" class="lineaInfPunta"><?php echo $row_Agregados['TxNomMat']; ?></td>
              <td width="65%" class="lineaInfPunta"><?php echo $row_Agregados['TxDesMat']; ?></td>
              <td width="5%" align="center" class="lineaInfPunta"><?php echo $row_Agregados['NuCanEntM']; ?></td>
            </tr>
            <?php } while ($row_Agregados = mysql_fetch_assoc($Agregados)); ?>
          </table>
      </td>
    </tr>
    <tr>
      <td height="53" align="center" bgcolor="#f0f0f0"> Sistema para el control de materiales del almacen del UPT &quot;Ludovico Silva&quot; sede Punta de Mata<br>
        Creado con el lenguaje php en 2013</td>
    </tr>
  </table>
</body>
</html>
<?php
mysql_free_result($entrada);

mysql_free_result($Agregados);
?>
